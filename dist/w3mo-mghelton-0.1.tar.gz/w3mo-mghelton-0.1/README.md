# w3mo
hack the wemo

# Installation
* clone repository
* run pip3 install .

# Usage
* run w3mo.py
* enter ip address of device
* enter desired state. 1 or 0!